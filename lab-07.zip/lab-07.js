/*
function throwGenericError() {
    throw "Generic error"
}
*/
class CustomError extends Error{

    constructor(args){
        super(args);
        this.message = "Custom error";
    }
    
    throwGenericError() {
        throw new Error("Generic Error");
    }

    throwCustomError() {
        throw new CustomError("Custom Error");
    }


}

//Elsewhere in our code
const myErrObj = new CustomError();
//myErrObj.throwGenericError();

console.log("Force generic error")
try {
    // Code that might have a problem
    // Examples: Connecting to a database
    // Divide by zero

    // Connect to database
    // Insert new data
    // Close database connection
    console.log("Generic error try block");
    myErrObj.throwGenericError();
    
    //console.log(33);
}
catch {
    // If the code in the try block "breaks" (that is, an error occurs: aka "error is thrown") run this code
    //console.log(myErrObj.throwGenericError());
    console.log("Generic error catch block");
    console.log(myErrObj.throwGenericError())
}
finally {
    // No matter what, regardless of whether the code broek or not, run this code
    console.log("Generic error finally block");
}

console.log("Force custom error");
try {
    // comment
    // Code that might have a problem
    // Examples: Connecting to a database
    // Divide by zero

    // Connect to database
    // Insert new data
    // Close database connection
    console.log("Custom error try block");
    myErrObj.throwCustomError();
    
    //console.log(33);
}
catch {
    // If the code in the try block "breaks" (that is, an error occurs: aka "error is thrown") run this code
    //console.log(myErrObj.throwGenericError());
    console.log("Custom error catch block");
    console.log(myErrObj.throwCustomError())
}
finally {
    // No matter what, regardless of whether the code broek or not, run this code
    console.log("Generic error finally block");
}